package com.onepiece.world

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONArray
import org.json.JSONObject
import java.util.concurrent.TimeUnit

data class ChatLine(val role: String, val text: String)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val prefs = getSharedPreferences("onepiece_world", MODE_PRIVATE)
        setContent {
            MaterialTheme {
                Surface(Modifier.fillMaxSize()) {
                    WorldApp(
                        getValue = { key, fallback -> prefs.getString(key, fallback) ?: fallback },
                        saveValue = { key, value -> prefs.edit().putString(key, value).apply() }
                    )
                }
            }
        }
    }
}

@Composable
fun WorldApp(getValue: (String, String) -> String, saveValue: (String, String) -> Unit) {
    var tab by remember { mutableStateOf(0) }
    var apiKey by remember { mutableStateOf(getValue("api_key", "")) }
    var model by remember { mutableStateOf(getValue("model", "gpt-6")) }
    var auName by remember { mutableStateOf(getValue("au_name", "마그마그 열매 / 백수 해적단 AU")) }
    var startPoint by remember { mutableStateOf(getValue("start_point", "사용자가 지정한 시점")) }
    var renProfile by remember { mutableStateOf(getValue("ren_profile", "렌의 나이·능력·소속·관계·현재 상태를 이 AU의 최신 확정 설정으로 입력하세요.")) }
    var worldNotes by remember { mutableStateOf(getValue("world_notes", "원작 고증을 기준으로 하되 렌의 행동에 따라 역사가 달라진다. 다른 AU와 설정을 섞지 않는다.")) }
    var input by remember { mutableStateOf("") }
    var busy by remember { mutableStateOf(false) }
    var status by remember { mutableStateOf("API 키를 설정하면 대화를 시작할 수 있어.") }
    val scope = rememberCoroutineScope()
    val lines = remember {
        mutableStateListOf<ChatLine>().apply {
            val raw = getValue("chat", "")
            if (raw.isNotBlank()) {
                runCatching {
                    val arr = JSONArray(raw)
                    for (i in 0 until arr.length()) {
                        val o = arr.getJSONObject(i)
                        add(ChatLine(o.optString("role"), o.optString("text")))
                    }
                }
            }
        }
    }
    fun persistChat() {
        val arr = JSONArray()
        lines.takeLast(80).forEach { arr.put(JSONObject().put("role", it.role).put("text", it.text)) }
        saveValue("chat", arr.toString())
    }
    val client = remember {
        OkHttpClient.Builder()
            .callTimeout(120, TimeUnit.SECONDS)
            .build()
    }
    val systemPrompt = """
너는 원피스 세계를 운영하는 장기 롤플레잉 시뮬레이터다.
운영 방식: 자유 시뮬레이션을 기본으로 하고 원작 고증과 렌의 행동에 따른 역사 변화를 결합한다.
원작의 인물 성격, 말투, 동기, 능력, 역사, 지리, 조직 구조를 기준으로 삼는다. 렌의 개입으로 사건의 결과와 이후 역사는 인과관계에 따라 달라진다.
렌이 없는 장소에서도 해적, 해군, 세계정부, 혁명군, 민간인과 각 세력은 자신들의 목적에 따라 독립적으로 행동한다.
NPC는 자신이 알고 있거나 관찰·추론할 수 있는 정보만 안다. 전지적 지식이나 자동 성공을 부여하지 않는다.
사용자가 조종하는 렌의 대사, 행동, 생각, 감정, 결정을 임의로 만들어내지 않는다. 렌의 행동이 필요한 순간에는 장면을 멈추고 사용자의 선택을 기다린다.
NPC를 렌에게 무조건 호의적으로 만들지 않는다. 갈등, 거래, 협력, 배신, 전투 결과는 인물의 성격·목표·정보·상황에서 도출한다.
설교, 도덕 훈계, 현대적 윤리 논평을 장면에 끼워 넣지 않는다. 대사는 인물답게 쓰고 불필요하게 순화하지 않는다.
전투는 능력, 패기, 경험, 체력, 부상, 지형, 정보, 전술을 고려해 일관되게 판정한다. 부상·피로·회복·시간·이동·경제·현상금·세력 변화를 추적한다.
확정되지 않은 설정은 사실처럼 만들지 않는다. 기존 기록과 충돌하면 임의로 덮어쓰지 말고 충돌을 표시해 사용자에게 확인한다.
AU 간 설정을 절대 혼합하지 않는다. 현재 선택된 AU만 적용한다.
가능하면 장면을 상세한 한국어 서술로 진행한다. 장면 끝에는 현재 상태와 NPC의 다음 판단·행동을 간결히 기록한다.
""".trimIndent()

    Column(Modifier.fillMaxSize().padding(12.dp)) {
        Text("ONE PIECE AI WORLD", style = MaterialTheme.typography.headlineSmall)
        Text("렌이 살아가는 원피스 세계 시뮬레이터", style = MaterialTheme.typography.bodySmall)
        TabRow(selectedTabIndex = tab) {
            Tab(selected = tab == 0, onClick = { tab = 0 }, text = { Text("세계/대화") })
            Tab(selected = tab == 1, onClick = { tab = 1 }, text = { Text("AU 설정") })
            Tab(selected = tab == 2, onClick = { tab = 2 }, text = { Text("API 설정") })
        }
        when (tab) {
            0 -> {
                Text("현재 AU: $auName", style = MaterialTheme.typography.titleSmall, modifier = Modifier.padding(vertical = 8.dp))
                LazyColumn(Modifier.weight(1f).fillMaxWidth(), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    items(lines) { line ->
                        Card(Modifier.fillMaxWidth()) {
                            Column(Modifier.padding(10.dp)) {
                                Text(if (line.role == "user") "렌 / 사용자" else "세계 / NPC", style = MaterialTheme.typography.labelMedium)
                                Text(line.text)
                            }
                        }
                    }
                }
                OutlinedTextField(value = input, onValueChange = { input = it }, modifier = Modifier.fillMaxWidth(), label = { Text("렌의 대사 또는 행동") }, minLines = 2)
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Button(
                        enabled = !busy && input.isNotBlank(),
                        onClick = {
                            val userText = input.trim()
                            input = ""
                            lines.add(ChatLine("user", userText))
                            persistChat()
                            busy = true
                            status = "세계가 반응하는 중..."
                            scope.launch {
                                try {
                                    val recent = lines.takeLast(24).joinToString("\n\n") {
                                        (if (it.role == "user") "사용자/렌: " else "AI/세계: ") + it.text
                                    }
                                    val prompt = """
$systemPrompt

[현재 AU]
$auName
[시작 시점]
$startPoint
[렌 프로필]
$renProfile
[세계 현황 및 추가 설정]
$worldNotes

[최근 대화]
$recent

위 설정과 대화의 연속성을 지켜 다음 장면을 진행하라. 사용자가 입력한 렌의 행동을 임의로 확장하거나 대신 결정하지 말라.
""".trimIndent()
                                    val answer = withContext(Dispatchers.IO) {
                                        val body = JSONObject()
                                            .put("model", model)
                                            .put("input", prompt)
                                            .put("store", false)
                                        val request = Request.Builder()
                                            .url("https://api.openai.com/v1/responses")
                                            .addHeader("Authorization", "Bearer $apiKey")
                                            .addHeader("Content-Type", "application/json")
                                            .post(body.toString().toRequestBody("application/json".toMediaType()))
                                            .build()
                                        client.newCall(request).execute().use { response ->
                                            val raw = response.body?.string().orEmpty()
                                            if (!response.isSuccessful) throw IllegalStateException("API 오류 ${response.code}: $raw")
                                            val json = JSONObject(raw)
                                            val output = json.optJSONArray("output") ?: JSONArray()
                                            val chunks = mutableListOf<String>()
                                            for (i in 0 until output.length()) {
                                                val content = output.optJSONObject(i)?.optJSONArray("content") ?: continue
                                                for (j in 0 until content.length()) {
                                                    val item = content.optJSONObject(j) ?: continue
                                                    if (item.optString("type") == "output_text") chunks.add(item.optString("text"))
                                                }
                                            }
                                            chunks.joinToString("\n").ifBlank { "응답 텍스트를 찾지 못했어. 모델 설정을 확인해 줘." }
                                        }
                                    }
                                    lines.add(ChatLine("assistant", answer))
                                    persistChat()
                                    status = "응답 완료"
                                } catch (e: Exception) {
                                    status = e.message ?: "알 수 없는 오류"
                                } finally { busy = false }
                            }
                        }
                    ) { Text(if (busy) "진행 중" else "보내기") }
                    OutlinedButton(onClick = { lines.clear(); persistChat(); status = "현재 대화 기록을 지웠어." }, enabled = !busy) { Text("대화 초기화") }
                }
                Text(status, style = MaterialTheme.typography.bodySmall)
            }
            1 -> {
                Column(Modifier.weight(1f).verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    OutlinedTextField(auName, { auName = it }, Modifier.fillMaxWidth(), label = { Text("AU 이름") })
                    OutlinedTextField(startPoint, { startPoint = it }, Modifier.fillMaxWidth(), label = { Text("시작 시점") })
                    OutlinedTextField(renProfile, { renProfile = it }, Modifier.fillMaxWidth(), label = { Text("렌의 확정 프로필") }, minLines = 5)
                    OutlinedTextField(worldNotes, { worldNotes = it }, Modifier.fillMaxWidth(), label = { Text("세계 현황 / 사건 / 연속성 메모") }, minLines = 7)
                    Button(onClick = {
                        saveValue("au_name", auName); saveValue("start_point", startPoint)
                        saveValue("ren_profile", renProfile); saveValue("world_notes", worldNotes)
                        status = "AU 설정을 기기에 저장했어."
                    }) { Text("AU 설정 저장") }
                    Text("팁: AU를 바꿀 때는 대화 초기화 후 이름과 프로필을 바꿔. 현재 버전은 AU별 프로필을 한 번에 하나씩 보관하는 초기 버전이야.")
                }
            }
            2 -> {
                Column(Modifier.weight(1f).verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Text("OpenAI API 연결", style = MaterialTheme.typography.titleMedium)
                    OutlinedTextField(apiKey, { apiKey = it }, Modifier.fillMaxWidth(), label = { Text("API 키") }, singleLine = true)
                    OutlinedTextField(model, { model = it }, Modifier.fillMaxWidth(), label = { Text("API 모델 이름") }, singleLine = true)
                    Button(onClick = {
                        saveValue("api_key", apiKey.trim()); saveValue("model", model.trim())
                        status = "API 설정을 기기에 저장했어."
                    }) { Text("API 설정 저장") }
                    Text("API 키는 이 휴대폰 앱 내부에 저장돼. 개인 테스트용으로만 사용하고 다른 사람에게 APK를 배포하지 마. ChatGPT 구독과 API 사용료는 별도야.")
                    Text("모델 이름은 네 API 계정에서 사용 가능한 모델 ID로 입력해야 해. 기본값이 작동하지 않으면 API 플랫폼에서 사용 가능한 모델을 확인해 바꿔 줘.")
                    Text("API 키 발급: https://platform.openai.com/api-keys")
                }
            }
        }
    }
}
